# Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          VECTORSHIFT PIPELINE BUILDER                        │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                 FRONTEND                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                          App.js (Main Container)                    │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                     │                                        │
│                  ┌──────────────────┼──────────────────┐                    │
│                  │                  │                  │                    │
│        ┌─────────▼────────┐ ┌──────▼──────┐ ┌────────▼────────┐           │
│        │  PipelineToolbar │ │ PipelineUI  │ │  SubmitButton   │           │
│        │  (toolbar.js)    │ │  (ui.js)    │ │  (submit.js)    │           │
│        └──────────────────┘ └─────────────┘ └─────────────────┘           │
│                │                    │                │                      │
│                │                    │                │                      │
│     ┌──────────▼──────────┐        │                │                      │
│     │  DraggableNode      │        │                │                      │
│     │  (9 Node Types)     │        │                │                      │
│     └─────────────────────┘        │                │                      │
│                                     │                │                      │
│                          ┌──────────▼────────┐       │                      │
│                          │   ReactFlow       │       │                      │
│                          │   - Canvas        │       │                      │
│                          │   - Controls      │       │                      │
│                          │   - MiniMap       │       │                      │
│                          └───────────────────┘       │                      │
│                                     │                │                      │
│                          ┌──────────▼────────┐       │                      │
│                          │   Node Types      │       │                      │
│                          ├───────────────────┤       │                      │
│                          │ ┌───────────────┐ │       │                      │
│                          │ │  BaseNode     │ │       │                      │
│                          │ │ (abstraction) │ │       │                      │
│                          │ └───────┬───────┘ │       │                      │
│                          │         │         │       │                      │
│                          │  ┌──────┴──────┐  │       │                      │
│                          │  │ createNode  │  │       │                      │
│                          │  │  (factory)  │  │       │                      │
│                          │  └──────┬──────┘  │       │                      │
│                          │         │         │       │                      │
│                          │   ┌─────▼─────┐   │       │                      │
│                          │   │ 9 Nodes:  │   │       │                      │
│                          │   │ - Input   │   │       │                      │
│                          │   │ - Output  │   │       │                      │
│                          │   │ - LLM     │   │       │                      │
│                          │   │ - Text    │   │       │                      │
│                          │   │ - API     │   │       │                      │
│                          │   │ - Database│   │       │                      │
│                          │   │ - Transform│  │       │                      │
│                          │   │ - Filter  │   │       │                      │
│                          │   │ - Merge   │   │       │                      │
│                          │   └───────────┘   │       │                      │
│                          └───────────────────┘       │                      │
│                                                       │                      │
│                          ┌────────────────────────────▼───────────┐         │
│                          │      Zustand Store (store.js)          │         │
│                          ├────────────────────────────────────────┤         │
│                          │  - nodes: []                           │         │
│                          │  - edges: []                           │         │
│                          │  - getNodeID()                         │         │
│                          │  - addNode()                           │         │
│                          │  - onNodesChange()                     │         │
│                          │  - onEdgesChange()                     │         │
│                          │  - onConnect()                         │         │
│                          │  - updateNodeField()                   │         │
│                          └────────────────────────────────────────┘         │
│                                                       │                      │
└───────────────────────────────────────────────────────┼──────────────────────┘
                                                        │
                                                        │ HTTP POST
                                                        │ /pipelines/parse
                                                        │
                                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                                 BACKEND                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                      FastAPI (main.py)                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │                                                                     │    │
│  │  ┌───────────────────────────────────────────────────────────┐    │    │
│  │  │  CORS Middleware                                           │    │    │
│  │  │  - Allow origin: http://localhost:3000                     │    │    │
│  │  │  - Allow credentials: true                                 │    │    │
│  │  │  - Allow methods: *                                        │    │    │
│  │  └───────────────────────────────────────────────────────────┘    │    │
│  │                                                                     │    │
│  │  ┌───────────────────────────────────────────────────────────┐    │    │
│  │  │  Pydantic Models                                           │    │    │
│  │  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │    │    │
│  │  │  │   Node       │  │    Edge      │  │   Pipeline   │   │    │    │
│  │  │  │ - id: str    │  │ - id: str    │  │ - nodes: []  │   │    │    │
│  │  │  │ - type: str  │  │ - source: str│  │ - edges: []  │   │    │    │
│  │  │  │ - data: dict │  │ - target: str│  │              │   │    │    │
│  │  │  └──────────────┘  └──────────────┘  └──────────────┘   │    │    │
│  │  └───────────────────────────────────────────────────────────┘    │    │
│  │                                                                     │    │
│  │  ┌───────────────────────────────────────────────────────────┐    │    │
│  │  │  Endpoints                                                 │    │    │
│  │  │                                                            │    │    │
│  │  │  GET /                                                     │    │    │
│  │  │  └─► { "Ping": "Pong" }                                   │    │    │
│  │  │                                                            │    │    │
│  │  │  POST /pipelines/parse                                    │    │    │
│  │  │  ├─► Receives: Pipeline(nodes, edges)                    │    │    │
│  │  │  ├─► Process: is_dag() function                          │    │    │
│  │  │  └─► Returns: {                                          │    │    │
│  │  │          num_nodes: int,                                 │    │    │
│  │  │          num_edges: int,                                 │    │    │
│  │  │          is_dag: bool                                    │    │    │
│  │  │      }                                                    │    │    │
│  │  └───────────────────────────────────────────────────────────┘    │    │
│  │                                                                     │    │
│  │  ┌───────────────────────────────────────────────────────────┐    │    │
│  │  │  is_dag() Function - Kahn's Algorithm                     │    │    │
│  │  │                                                            │    │    │
│  │  │  1. Build adjacency list from edges                       │    │    │
│  │  │  2. Calculate in-degree for each node                     │    │    │
│  │  │  3. Queue all nodes with in-degree 0                      │    │    │
│  │  │  4. Process queue:                                        │    │    │
│  │  │     - Remove node from queue                              │    │    │
│  │  │     - Decrement in-degree of neighbors                    │    │    │
│  │  │     - Add neighbors with in-degree 0 to queue             │    │    │
│  │  │  5. If all nodes processed → DAG                          │    │    │
│  │  │     Otherwise → Contains cycle                            │    │    │
│  │  │                                                            │    │    │
│  │  │  Time Complexity: O(V + E)                                │    │    │
│  │  │  Space Complexity: O(V + E)                               │    │    │
│  │  └───────────────────────────────────────────────────────────┘    │    │
│  │                                                                     │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                            DATA FLOW DIAGRAM                                 │
└─────────────────────────────────────────────────────────────────────────────┘

   USER INTERACTION
         │
         ▼
   ┌──────────┐
   │  Drag    │ ──────► Toolbar ──────► Canvas ──────► Zustand Store
   │  Nodes   │                                            │
   └──────────┘                                            │
         │                                                  │
         ▼                                                  │
   ┌──────────┐                                            │
   │ Connect  │ ──────► ReactFlow ─────► Edges ──────────┘
   │  Edges   │                             │
   └──────────┘                             │
         │                                  │
         ▼                                  │
   ┌──────────┐                             │
   │   Edit   │ ──────► Node Fields ───────┘
   │  Fields  │              │
   └──────────┘              │ (for Text node)
         │                   │
         ▼                   ▼
   ┌──────────┐      ┌──────────────┐
   │  Type    │      │ Detect {{}}  │
   │   in     │ ────►│  Variables   │──────► Create Dynamic Handles
   │  Text    │      └──────────────┘
   └──────────┘              │
         │                   │
         │                   ▼
         │           ┌──────────────┐
         │           │   Resize     │
         │           │   Node       │──────► Update Dimensions
         │           └──────────────┘
         │
         ▼
   ┌──────────┐
   │  Click   │
   │  Submit  │
   └────┬─────┘
        │
        ▼
   Serialize { nodes: [], edges: [] }
        │
        ▼
   POST http://localhost:8000/pipelines/parse
        │
        ▼
   ┌─────────────────────────────────┐
   │      Backend Processing          │
   │  1. Validate with Pydantic       │
   │  2. Count nodes                  │
   │  3. Count edges                  │
   │  4. Run DAG detection            │
   │  5. Return results               │
   └────────────┬────────────────────┘
                │
                ▼
   { num_nodes: int, num_edges: int, is_dag: bool }
                │
                ▼
   ┌────────────▼──────────────┐
   │     Display Modal          │
   │  - Show node count         │
   │  - Show edge count         │
   │  - Show DAG status         │
   │  - Warning if cycle        │
   └────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                        NODE CREATION FLOW                                    │
└─────────────────────────────────────────────────────────────────────────────┘

    OLD WAY (Without BaseNode):
    ──────────────────────────────
    
    1. Copy existing node file (50+ lines)
    2. Modify imports
    3. Change state variables
    4. Update JSX structure
    5. Adjust styling
    6. Configure handles
    7. Test and debug
    
    Time: ~30-60 minutes per node
    Code Duplication: HIGH
    Maintenance: DIFFICULT


    NEW WAY (With BaseNode):
    ─────────────────────────
    
    1. Create config object (15-20 lines)
    2. Call createNode(config)
    3. Export node component
    
    Time: ~5-10 minutes per node
    Code Duplication: NONE
    Maintenance: EASY
    
    
    Example:
    ────────
    
    const apiNodeConfig = {
      title: 'API',
      fields: [...],
      inputs: [...],
      outputs: [...],
      styles: {...}
    };
    
    export const APINode = createNode(apiNodeConfig);


┌─────────────────────────────────────────────────────────────────────────────┐
│                         TECH STACK OVERVIEW                                  │
└─────────────────────────────────────────────────────────────────────────────┘

    FRONTEND
    ────────
    ┌─────────────┐
    │   React     │ ──► Component Framework
    │   18.2.0    │
    └──────┬──────┘
           │
           ├──► ReactFlow 11.8.3 ──► Canvas, Nodes, Edges
           │
           ├──► Zustand ──────────► State Management
           │
           ├──► CSS3 ─────────────► Styling, Animations
           │
           └──► Fetch API ────────► HTTP Requests


    BACKEND
    ───────
    ┌─────────────┐
    │   Python    │ ──► Programming Language
    │   3.x       │
    └──────┬──────┘
           │
           ├──► FastAPI ──────────► Web Framework
           │
           ├──► Pydantic ─────────► Data Validation
           │
           ├──► Uvicorn ──────────► ASGI Server
           │
           └──► Collections ──────► Graph Algorithms


    ALGORITHMS
    ──────────
    • Kahn's Algorithm (DAG Detection)
    • Regex Pattern Matching (Variables)
    • Topological Sort (Graph Processing)


┌─────────────────────────────────────────────────────────────────────────────┐
│                              FILE TREE                                       │
└─────────────────────────────────────────────────────────────────────────────┘

VectorShift/
│
├── frontend/
│   └── src/
│       ├── nodes/
│       │   ├── BaseNode.js          ⭐ Core abstraction
│       │   ├── inputNode.js         ✏️ Refactored
│       │   ├── outputNode.js        ✏️ Refactored
│       │   ├── llmNode.js           ✏️ Refactored
│       │   ├── textNode.js          ⭐ Enhanced
│       │   ├── apiNode.js           ✨ New
│       │   ├── databaseNode.js      ✨ New
│       │   ├── transformNode.js     ✨ New
│       │   ├── filterNode.js        ✨ New
│       │   └── mergeNode.js         ✨ New
│       │
│       ├── App.js                   ✏️ Layout
│       ├── toolbar.js               ✏️ Styled
│       ├── ui.js                    ✏️ Nodes registered
│       ├── submit.js                ⭐ Backend integration
│       ├── draggableNode.js         ✏️ Styled
│       ├── store.js                 (Unchanged)
│       └── index.css                ✏️ Global styles
│
├── backend/
│   └── main.py                      ⭐ DAG detection
 

Legend:
⭐ Major changes
✏️ Modified
✨ New file
📚 Documentation
```
